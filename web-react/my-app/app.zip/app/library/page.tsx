"use client";
import LibraryTable from "../components/LibraryTable";

export default function LibraryPage() {
  return (
    <div id="library" className="library-menu section active">
      <h1>Your Library</h1>
      <div className="table">
        <div className="table-header">
          <div className="col index">#</div>
          <div className="col title">Title</div>
          <div className="col artist">Artist</div>
          <div className="col duration">Duration</div>
        </div>
        <LibraryTable />
      </div>
    </div>
  );
}
