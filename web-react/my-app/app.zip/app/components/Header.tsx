"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function Header() {
  const [q, setQ] = useState("");
  return (
    <header className="header">
      <div className="back-next-search">
        <div className="back chevron">
          <button>
            <i className="fa-solid fa-chevron-left" />
          </button>
        </div>
        <div className="next chevron">
          <button>
            <i className="fa-solid fa-chevron-right" />
          </button>
        </div>
        <div className="search-box">
          <i className="fa-solid fa-magnifying-glass i-search" />
          <input
            className="input-text"
            placeholder="Bạn muốn phát nội dung gì?"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </div>

      <div className="header-right">
        <button className="sign-up head">
          <a href="#" className="a-sign-up">
            Sign up
          </a>
        </button>
        <button className="login head">
          <a href="#">Sign in</a>
        </button>
      </div>
    </header>
  );
}
