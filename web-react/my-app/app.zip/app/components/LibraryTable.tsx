"use client";
import React, { useState, useEffect } from "react";
import "./library.css";

interface Song {
  id: number;
  title: string;
  artist: string;
  duration: string;
}

const mockSongs: Song[] = [
  { id: 1, title: "Lối Nhỏ", artist: "Đen Vâu", duration: "3:45" },
  { id: 2, title: "Waiting For You", artist: "Mono", duration: "4:10" },
  { id: 3, title: "Chạy Ngay Đi", artist: "Sơn Tùng M-TP", duration: "3:30" },
  { id: 4, title: "Có Em", artist: "Madihu", duration: "3:55" },
];

const LibraryTable: React.FC = () => {
  const [songs, setSongs] = useState<Song[]>([]);

  useEffect(() => {
    // sau này có thể fetch API ở đây
    setSongs(mockSongs);
  }, []);

  return (
    <div className="library-menu section">
      <h1>Your Library</h1>

      <div className="table">
        <div className="table-header">
          <div className="col index">#</div>
          <div className="col title">Title</div>
          <div className="col artist">Artist</div>
          <div className="col duration">Duration</div>
        </div>

        <div id="rowTable">
          {songs.map((song, index) => (
            <div className="table-row" key={song.id}>
              <div className="col index">{index + 1}</div>
              <div className="col title">{song.title}</div>
              <div className="col artist">{song.artist}</div>
              <div className="col duration">{song.duration}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LibraryTable;
