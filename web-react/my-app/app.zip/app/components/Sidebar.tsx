"use client";
import Link from "next/link";

export default function Sidebar() {
  return (
    <div className="menu">
      <div className="logo">
        <Link href="/">
          <img src="/images/logo.png" alt="logo web page" />
        </Link>
      </div>
      <nav>
        <Link href="/" className="active" data-section="home">
          <i className="fa-regular fa-compass" /> Explore
        </Link>
        <Link href="/library" data-section="library">
          <i className="fa-solid fa-book" /> Library
        </Link>
        <Link href="/myplaylists" data-section="playlist">
          <i className="fa-solid fa-list" /> My Playlist
        </Link>
      </nav>
    </div>
  );
}
