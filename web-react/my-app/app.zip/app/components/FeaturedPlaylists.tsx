"use client";
import React, { useState, useEffect } from "react";
import "./Playlists.css";

interface Playlist {
  id: number;
  title: string;
  creator: string;
  image: string;
}

const mockFeaturedPlaylists: Playlist[] = [
  {
    id: 1,
    title: "Top Hits Vietnam",
    creator: "NhacCuaTui",
    image:
      "https://photo-resize-zmp3.zmdcdn.me/w600_r1x1_jpeg/cover/2/3/5/8/2358f0a9b5c16c0a9ff14d6b11b27b91.jpg",
  },
  {
    id: 2,
    title: "Chill & Relax",
    creator: "Various Artists",
    image:
      "https://photo-resize-zmp3.zmdcdn.me/w600_r1x1_jpeg/cover/e/b/f/d/ebfd1c02b60f3c4a8e7a68cbadb65a6c.jpg",
  },
  {
    id: 3,
    title: "Love Songs Collection",
    creator: "Ballad Việt",
    image:
      "https://photo-resize-zmp3.zmdcdn.me/w600_r1x1_jpeg/cover/9/8/7/0/9870c2d8a10f27b32f1e4d62e38f3a7c.jpg",
  },
  {
    id: 4,
    title: "EDM Festival 2025",
    creator: "DJ Mix Team",
    image:
      "https://photo-resize-zmp3.zmdcdn.me/w600_r1x1_jpeg/cover/1/2/3/4/1234abcd5678ef9012345678abcd1234.jpg",
  },
  {
    id: 5,
    title: "Lo-fi Nights",
    creator: "Study Beats",
    image:
      "https://photo-resize-zmp3.zmdcdn.me/w600_r1x1_jpeg/cover/7/4/6/b/746bf14bdf4e5e84a8d9a97b1a8b511b.jpg",
  },
];

const FeaturedPlaylists: React.FC = () => {
  const [playlists, setPlaylists] = useState<Playlist[]>([]);

  useEffect(() => {
    // Sau này có thể fetch từ API, ví dụ: Jamendo / Spotify / backend
    setPlaylists(mockFeaturedPlaylists);
  }, []);

  return (
    <section className="featured section">
      <div className="featured-header">
        <h1>Featured Playlists</h1>
        <p className="featured-subtitle">Enjoy trending playlists this week</p>
      </div>

      <div className="featured-grid">
        {playlists.map((playlist) => (
          <div key={playlist.id} className="featured-card">
            <div className="featured-img-wrapper">
              <img
                src={playlist.image}
                alt={playlist.title}
                className="featured-img"
              />
            </div>
            <div className="featured-info">
              <h3 className="featured-title">{playlist.title}</h3>
              <p className="featured-creator">By {playlist.creator}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default FeaturedPlaylists;
