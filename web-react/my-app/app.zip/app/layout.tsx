import "./styles/globals.css";
import "./styles/home.css";
import "./styles/library.css";
import "./styles/myplaylists.css";
import Player from "./components/Player";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import { PlayerProvider } from "./context/PlayerContext";

export const metadata = {
  title: "NhacCuaTui",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="vi">
      <body>
        <PlayerProvider>
          <Sidebar />
          <div className="main">
            {/* main wrapper: header + content + footer */}
            <Header />
            <div id="content" className="content">
              {children}
            </div>
          </div>
          <Player />
        </PlayerProvider>
      </body>
    </html>
  );
}
